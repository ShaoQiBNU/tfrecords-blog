package util;

import org.apache.flink.core.io.SimpleVersionedSerializer;
import org.apache.flink.streaming.api.functions.sink.filesystem.BucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.SimpleVersionedStringSerializer;

/**
 * 默认的分桶方式是 DateTimeBucketAssigner，按照处理时间分桶。
 * 处理时间指的是消息到达 Flink 程序的时间
 */
public class BucketUtil implements BucketAssigner<byte[], String> {

    public String outPutDate;

    public BucketUtil(String outPutDate) {
        this.outPutDate = outPutDate;
    }

    @Override
    public String getBucketId(byte[] bytes, Context context) {

        return this.outPutDate;
    }

    @Override
    public SimpleVersionedSerializer<String> getSerializer() {
        return SimpleVersionedStringSerializer.INSTANCE;
    }
}