package util;

import org.apache.flink.streaming.api.functions.sink.filesystem.RollingPolicy;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;

public class RollingPolicyUtil {

    /**
     * 获取默认滚动策略
     * @param rolloverTime   每隔多久（指定）时间生成一个新文件
     * @param inactivityTime 每隔多久（指定）未活动数据，则将上一段时间（无数据时间段）生成一个文件
     * @param size           每size大小文件进行滚动
     * @return 默认配置滚动策略
     */
    public static RollingPolicy getDefaultRollingPolicy(long rolloverTime, long inactivityTime, long size) {
        return DefaultRollingPolicy.builder()
                .withRolloverInterval(rolloverTime)
                .withInactivityInterval(inactivityTime)
                .withMaxPartSize(size)
                .build();
    }
}
