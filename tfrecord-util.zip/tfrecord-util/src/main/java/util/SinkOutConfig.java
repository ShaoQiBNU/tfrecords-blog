package util;

import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;

public class SinkOutConfig {

    /**
     * 输出到hdfs文件的名称配置
     * @param prefix 输出文件前缀
     * @param suffix 输出文件后缀
     * @return 返回hdfs文件名称的配置
     */
    public static OutputFileConfig getOutConfig(String prefix, String suffix) {
        OutputFileConfig.OutputFileConfigBuilder fileBuilder = OutputFileConfig.builder();
        prefix = prefix == null ? "" : prefix;
        suffix = suffix == null ? "" : suffix;
        return fileBuilder.withPartPrefix(prefix).withPartSuffix(suffix).build();
    }

}
