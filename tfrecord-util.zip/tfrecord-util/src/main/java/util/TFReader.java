package util;

import org.apache.flink.connector.file.src.reader.StreamFormat.Reader;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;

public class TFReader implements Reader<byte[]> {

    InputStream stream;
    TFRecordReader rd;

    public TFReader(InputStream stream) {
        this.stream = stream;
        this.rd = new TFRecordReader(stream, false);
    }

    @Nullable
    @Override
    public byte[] read() throws IOException {
        return rd.read();
    }

    @Override
    public void close() throws IOException {
        this.stream.close();
    }
}
