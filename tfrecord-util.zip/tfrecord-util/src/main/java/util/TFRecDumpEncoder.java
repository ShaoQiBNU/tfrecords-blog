package util;

import org.apache.flink.api.common.serialization.Encoder;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class TFRecDumpEncoder implements Encoder<byte[]> {

    /**
     * wrap bytes as TFRecord format
     * @param data        bytes of featuredump message
     * @param outputStream output stream
     * @throws IOException exception
     */
    @Override
    public void encode(byte[] data, OutputStream outputStream)
            throws IOException {
        byte[] len = toInt64LE(data.length);
        // 前面4个字节写入长度 4个字节
        outputStream.write(len);
        // 写入 crc 校验 4个字节
        outputStream.write(toInt32LE(Crc32C.maskedCrc32c(len)));
        // 写入真实数据 N个字节
        outputStream.write(data);
        // 写入 crc校验 4个字节
        outputStream.write(toInt32LE(Crc32C.maskedCrc32c(data,0,data.length)));
    }

    private byte[] toInt64LE(long data) {
        byte[] buff = new byte[8];
        ByteBuffer bb = ByteBuffer.wrap(buff);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        bb.putLong(data);
        return buff;
    }

    private byte[] toInt32LE(int data) {
        byte[] buff = new byte[4];
        ByteBuffer bb = ByteBuffer.wrap(buff);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(data);
        return buff;
    }
}
