package util;

import org.apache.flink.api.common.io.FileInputFormat;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.FileInputSplit;
import org.apache.flink.core.fs.Path;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class TFRecordInputFormat extends FileInputFormat<byte[]> {

    private static final Logger LOG = LoggerFactory.getLogger(TFRecordInputFormat.class);
    private transient TFRecordReader tfRecordReader;

    private transient FSDataInputStream fsdis;
    private boolean end = false;

    public TFRecordInputFormat(Path path) {
        super(path);
        this.unsplittable = true;
    }

    @Override
    public void open(FileInputSplit split) throws IOException {
        org.apache.hadoop.conf.Configuration configuration = new org.apache.hadoop.conf.Configuration();
        final org.apache.hadoop.fs.Path file = new org.apache.hadoop.fs.Path(split.getPath().toUri());
        LOG.info("open split path: {}", file.toString());
        FileSystem fs = null;
        fs = file.getFileSystem(configuration);
        fsdis = fs.open(file, 16 * 1024 * 1024);
        tfRecordReader = new TFRecordReader(fsdis, true);
    }


    @Override
    public void configure(Configuration configuration) {
        super.configure(configuration);
    }

    @Override
    public boolean reachedEnd() throws IOException {
        return end;
    }

    @Override
    public byte[] nextRecord(byte[] bytes) throws IOException {
        byte[] record = tfRecordReader.read();
        if (null == record) {
            end = true;
        }
        return record;
    }

    @Override
    public void close() throws IOException {
        if (fsdis != null) {
            fsdis.close();
        }
    }

    TFRecordReader getTfRecordReader() {
        return tfRecordReader;
    }

}
