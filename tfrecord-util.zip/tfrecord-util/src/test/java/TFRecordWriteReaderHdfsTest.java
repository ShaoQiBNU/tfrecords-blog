import com.org.tensorflow.example.*;
import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.connector.file.sink.FileSink;
import org.apache.flink.connector.file.src.FileSource;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;
import org.apache.flink.streaming.api.functions.sink.filesystem.RollingPolicy;
import org.junit.jupiter.api.Test;
import util.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class TFRecordWriteReaderHdfsTest {

    @Test
    public void testReader() throws Exception {

        // ========== 设置flink运行模式为Batch ==========
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setRuntimeMode(RuntimeExecutionMode.BATCH);

        // ========== 批量读取hdfs上的tf格式文件，此数据是线上落盘的样本流，但不是标准tf格式 ==========
        String hdfsDumpPath = "your hdfs data path";
        TFRecordInputFormat format = new TFRecordInputFormat(new Path(hdfsDumpPath));
        format.setNestedFileEnumeration(true);

        FileSource<byte[]> source = FileSource.forRecordStreamFormat(new ArrayReaderFormat(), new Path(hdfsDumpPath)).build();
        DataStream<byte[]> rowStream = env.fromSource(source, WatermarkStrategy.noWatermarks(), "test_data");

        // ========== 转成标准tf格式 此处根据实际情况修改 ==========
        DataStream<byte[]> resultTf = rowStream.map(new MapFunction<byte[], byte[]>() {
            @Override
            public byte[] map(byte[] bytes) throws Exception {
                Example.Builder build = Example.newBuilder();
                Features.Builder features = Features.newBuilder();

                Feature.Builder intListFeature = Feature.newBuilder();
                Int64List.Builder intListInput = Int64List.newBuilder();
                List<Long> value = new ArrayList<>();
                value.add(9L);
                intListInput.addAllValue(value);
                intListFeature.setInt64List(intListInput);

                Feature.Builder floatListFeature = Feature.newBuilder();
                FloatList.Builder floatListInput = FloatList.newBuilder();
                List<Float> valueFloat = new ArrayList<>();
                valueFloat.add((float) 1.20);
                floatListInput.addAllValue(valueFloat);
                floatListFeature.setFloatList(floatListInput);

                features.putFeature("floatFeature", floatListFeature.build());
                features.putFeature("intFeature", intListFeature.build());

                build.setFeatures(features);
                return build.build().toByteArray();
            }
        });

        // ========== 样本落到hdfs，按照设定日期分桶 ==========
        String hdfsSamplePath = "your tf data saving hdfs path";
        Path path = new Path(hdfsSamplePath);
        OutputFileConfig config = SinkOutConfig.getOutConfig("part", "");
        RollingPolicy defaultRollingPolicy = RollingPolicyUtil.getDefaultRollingPolicy(
                TimeUnit.HOURS.toMillis(2),
                TimeUnit.MINUTES.toMillis(30),
                1024 * 1024 * 1024);

        FileSink<byte[]> hdfsSink = FileSink.forRowFormat(path, new TFRecDumpEncoder())
                .withBucketAssigner(new BucketUtil("2022-02-09"))
                .withRollingPolicy(defaultRollingPolicy)
                .withOutputFileConfig(config)
                .build();

        resultTf.sinkTo(hdfsSink).name("Sample to Hdfs");

        env.execute("Success");

    }
}
