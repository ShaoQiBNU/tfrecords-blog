import com.org.tensorflow.example.*;
import org.junit.jupiter.api.Test;
import util.TFRecordReader;
import util.TFRecordWriter;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TFRecordWriteReaderTest {

    @Test
    public void testReader() {

        String path = "src/main/resources/test.txt";
        String testData = "hello world";

        //写测试数据到test文件中
        try (DataOutputStream dops = new DataOutputStream(new FileOutputStream(path, true))) {
            TFRecordWriter tfRecordWriter = new TFRecordWriter(dops);
            tfRecordWriter.write(testData.getBytes());
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        // 从test文件中读出测试数据
        try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(path))) {
            TFRecordReader tfRecordReader = new TFRecordReader(dataInputStream, true);
            byte[] read = tfRecordReader.read();
            String res = new String(read);
            assert (testData.equals(res)) : true;
            System.out.println(res);
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }


        String pathTf = "src/main/resources/test1.txt";
        //数据用标准tf格式写入到test文件中
        try (DataOutputStream dops = new DataOutputStream(new FileOutputStream(pathTf, true))) {

            TFRecordWriter tfRecordWriter = new TFRecordWriter(dops);

            Example.Builder build = Example.newBuilder();
            Features.Builder features = Features.newBuilder();

            Feature.Builder intListFeature = Feature.newBuilder();
            Int64List.Builder intListInput = Int64List.newBuilder();
            List<Long> value = new ArrayList<>();
            value.add(9L);
            intListInput.addAllValue(value);
            intListFeature.setInt64List(intListInput);

            Feature.Builder floatListFeature = Feature.newBuilder();
            FloatList.Builder floatListInput = FloatList.newBuilder();
            List<Float> valueFloat = new ArrayList<>();
            valueFloat.add((float) 1.20);
            floatListInput.addAllValue(valueFloat);
            floatListFeature.setFloatList(floatListInput);

            features.putFeature("floatFeature", floatListFeature.build());
            features.putFeature("intFeature", intListFeature.build());

            build.setFeatures(features);
            tfRecordWriter.write(build.build().toByteArray());


        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }


        // 从test文件中读出标准格式的tf数据
        try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(pathTf))) {
            TFRecordReader tfRecordReader = new TFRecordReader(dataInputStream, true);
            while(tfRecordReader.read() != null) {
                byte[] read = tfRecordReader.read();
                Example.Builder example = Example.parseFrom(read).toBuilder();;
                Features features = example.getFeatures();
                List<Float> floatFeature = features.getFeatureMap().getOrDefault("floatFeature", null).getFloatList().getValueList();
                List<Long> intFeature = features.getFeatureMap().getOrDefault("intFeature", null).getInt64List().getValueList();
                System.out.println(floatFeature);
                System.out.println(intFeature);

            }


        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
